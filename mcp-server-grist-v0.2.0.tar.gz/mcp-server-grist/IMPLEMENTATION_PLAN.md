# Plan d'implémentation MCP Server Grist v0.2.0

## Vue d'ensemble

Ce document décrit le plan d'implémentation complet pour la version 0.2.0 du MCP Server Grist, incluant les corrections de bugs et les nouvelles fonctionnalités.

## 📁 Structure des fichiers

```
mcp-server-grist/
├── src/
│   └── mcp_server_grist/
│       ├── types.py              # Types et validations
│       └── tools/
│           ├── __init__.py       # Exports des tools
│           ├── utils.py          # Fonctions utilitaires
│           ├── administration.py # Tables et colonnes (corrigé)
│           ├── schema.py         # Nouveaux outils schéma
│           └── downloads.py      # Exports CSV/Excel (corrigé)
├── tests/
│   └── test_schema.py            # Tests unitaires
├── pyproject.toml                # Configuration package
├── README.md                     # Documentation
└── CHANGELOG.md                  # Historique des versions
```

## 🔧 Corrections de bugs

### 1. Format `create_table` (Critique)

**Problème** : L'API Grist attend un format spécifique que le code ne respectait pas.

**Avant** :
```python
payload = {
    "tables": [{
        "tableId": table_id,
        "columns": columns
    }]
}
```

**Après** :
```python
payload = {
    "tables": [{
        "id": table_id,
        "columns": [
            {
                "id": col["id"],
                "fields": {k: v for k, v in col.items() if k != "id"}
            }
            for col in columns
        ]
    }]
}
```

### 2. Format `modify_table` (Critique)

**Avant** :
```python
payload = {"tables": [{"tableId": old_id, "newTableId": new_id}]}
```

**Après** :
```python
payload = {"tables": [{"id": old_id, "fields": {"tableId": new_id}}]}
```

### 3. Sérialisation `widgetOptions` (Critique)

**Problème** : L'API attend une string JSON, pas un dict.

**Solution** :
```python
if widget_options is not None:
    if isinstance(widget_options, dict):
        fields["widgetOptions"] = json.dumps(widget_options)
    else:
        fields["widgetOptions"] = widget_options
```

### 4. Support `choices` pour Choice/ChoiceList

**Ajout** :
```python
def prepare_column_payload(..., choices=None):
    opts = widget_options.copy() if widget_options else {}
    if choices and column_type in ("Choice", "ChoiceList"):
        opts["choices"] = choices
    if opts:
        fields["widgetOptions"] = json.dumps(opts)
```

## 🆕 Nouvelles fonctionnalités

### 1. `create_reference_column`

Crée une colonne référence avec résolution automatique de `visibleCol`.

```python
async def create_reference_column(
    doc_id: str,
    table_id: str,
    column_id: str,
    target_table: str,
    visible_column: str,    # Nom, pas colRef
    is_list: bool = False,
    label: Optional[str] = None,
    reverse_column: Optional[str] = None
) -> Dict[str, Any]
```

**Algorithme** :
1. Vérifier que `target_table` existe
2. Résoudre `visible_column` → `colRef` via GET /columns
3. Créer la colonne avec le bon `visibleCol`
4. Si `reverse_column`, créer la RefList inverse

### 2. `validate_schema`

Valide un schéma sans le créer.

```python
async def validate_schema(
    doc_id: str,
    schema: Dict[str, Any]
) -> Dict[str, Any]
```

**Vérifications** :
- Syntaxe du schéma
- Tables cibles existantes pour les références
- Colonnes Choice avec/sans choix
- Colonnes visibles existantes

### 3. `create_schema`

Crée un schéma complet avec tables, colonnes et relations.

```python
async def create_schema(
    doc_id: str,
    schema: Dict[str, Any],
    skip_existing: bool = True,
    insert_data: bool = True
) -> Dict[str, Any]
```

**Algorithme en 5 phases** :

```
┌─────────────────────────────────────────┐
│ PHASE 1: VALIDATION                     │
│ - Parser le schéma                      │
│ - Valider les références                │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│ PHASE 2: CRÉATION DES TABLES            │
│ - Filtrer colonnes simples              │
│ - POST /tables pour chaque table        │
│ - Enregistrer mapping table_id          │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│ PHASE 3: CACHE DES colRef               │
│ - GET /columns pour chaque table cible  │
│ - Construire mapping nom → colRef       │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│ PHASE 4: COLONNES RÉFÉRENCE             │
│ - Résoudre target_table                 │
│ - Résoudre visible_column → colRef      │
│ - POST /columns avec Ref:Table          │
│ - Créer relations inverses              │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│ PHASE 5: INSERTION DES DONNÉES          │
│ - POST /records pour chaque table       │
│ - Rapport final                         │
└─────────────────────────────────────────┘
```

### 4. `export_schema`

Exporte le schéma d'un document existant.

```python
async def export_schema(
    doc_id: str,
    format: str = "json",  # "json", "yaml", "mermaid"
    include_data: bool = False
) -> Dict[str, Any]
```

**Formats supportés** :
- `json` : Structure complète réutilisable
- `yaml` : Lecture humaine facile
- `mermaid` : Diagramme ER visualisable

## 📝 Format de schéma

```python
{
    "tables": {
        "TableName": {
            "columns": {
                "column_id": {
                    "type": "Text|Numeric|Int|Bool|Date|DateTime|Choice|ChoiceList|Ref|RefList",
                    "label": "Label affiché",
                    "formula": "$col1 + $col2",  # Optionnel
                    "description": "Description",  # Optionnel
                    "choices": ["A", "B", "C"],   # Pour Choice/ChoiceList
                    "target": "TargetTable",      # Pour Ref/RefList
                    "visible": "column_name",     # Colonne affichée pour Ref
                    "reverse": "reverse_column"   # Relation inverse
                }
            }
        }
    },
    "data": {
        "TableName": [
            {"column1": "value1", "column2": "value2"}
        ]
    }
}
```

## ✅ Ordre d'implémentation

| # | Fichier | Action | Priorité | Statut |
|---|---------|--------|----------|--------|
| 1 | `types.py` | Créer types et validations | 🔴 Critique | ✅ |
| 2 | `tools/utils.py` | Créer fonctions utilitaires | 🔴 Critique | ✅ |
| 3 | `tools/administration.py` | Corriger create_table | 🔴 Critique | ✅ |
| 4 | `tools/administration.py` | Corriger modify_table | 🔴 Critique | ✅ |
| 5 | `tools/administration.py` | Corriger create_column | 🔴 Critique | ✅ |
| 6 | `tools/administration.py` | Corriger modify_column | 🔴 Critique | ✅ |
| 7 | `tools/downloads.py` | Corriger exports | 🟡 Important | ✅ |
| 8 | `tools/schema.py` | create_reference_column | 🟢 Nouveau | ✅ |
| 9 | `tools/schema.py` | validate_schema | 🟢 Nouveau | ✅ |
| 10 | `tools/schema.py` | create_schema | 🟢 Nouveau | ✅ |
| 11 | `tools/schema.py` | export_schema | 🟢 Nouveau | ✅ |
| 12 | `tests/test_schema.py` | Tests unitaires | 🟡 Important | ✅ |
| 13 | `pyproject.toml` | Version 0.2.0 | - | ✅ |

## 🧪 Tests

```bash
# Installation
cd mcp-server-grist
pip install -e ".[dev]"

# Exécution des tests
pytest tests/ -v

# Avec couverture
pytest tests/ --cov=mcp_server_grist --cov-report=html
```

## 📦 Publication

```bash
# Build
python -m build

# Publication PyPI
python -m twine upload dist/*
```

## 🔄 Migration

Pour les utilisateurs de la version 0.1.x :

1. **Aucune modification requise** pour les appels existants
2. Les corrections sont rétrocompatibles
3. Nouveaux outils optionnels

## 📊 Exemple complet

```python
# Création d'un schéma de gestion de projet
schema = {
    "tables": {
        "Agents": {
            "columns": {
                "nom": {"type": "Text", "label": "Nom"},
                "prenom": {"type": "Text", "label": "Prénom"},
                "service": {
                    "type": "Choice",
                    "choices": ["GIDI", "DTerMed", "Direction"]
                },
                "nom_complet": {
                    "type": "Text",
                    "formula": "$prenom + ' ' + $nom"
                }
            }
        },
        "Projets": {
            "columns": {
                "nom": {"type": "Text"},
                "budget": {"type": "Numeric"},
                "chef": {
                    "type": "Ref",
                    "target": "Agents",
                    "visible": "nom_complet"
                }
            }
        },
        "Taches": {
            "columns": {
                "titre": {"type": "Text"},
                "projet": {
                    "type": "Ref",
                    "target": "Projets",
                    "visible": "nom",
                    "reverse": "taches"
                },
                "assignee": {
                    "type": "Ref",
                    "target": "Agents",
                    "visible": "nom_complet"
                },
                "statut": {
                    "type": "Choice",
                    "choices": ["À faire", "En cours", "Terminé"]
                }
            }
        }
    },
    "data": {
        "Agents": [
            {"nom": "LAVAL", "prenom": "Nicolas", "service": "GIDI"}
        ]
    }
}

# Validation
result = await validate_schema(doc_id, schema)
if result["valid"]:
    # Création
    result = await create_schema(doc_id, schema)
    print(f"Créé: {result['report']['tables_created']}")
```
