# MCP Server Grist

[![PyPI version](https://badge.fury.io/py/mcp-server-grist.svg)](https://badge.fury.io/py/mcp-server-grist)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Serveur MCP (Model Context Protocol) pour [Grist](https://www.getgrist.com/), la plateforme collaborative de bases de données.

## 🚀 Fonctionnalités

### v0.2.0 - Nouveautés

- **`create_schema`** : Création de schémas complets avec tables, colonnes et relations en une seule opération
- **`create_reference_column`** : Création de références avec résolution automatique des `visibleCol`
- **`validate_schema`** : Validation de schémas avant création
- **`export_schema`** : Export de schémas existants (JSON, YAML, Mermaid)

### Corrections

- ✅ Format `create_table` corrigé (payload API)
- ✅ Format `modify_table` corrigé
- ✅ `widgetOptions` sérialisé correctement en JSON string
- ✅ Gestion des `choices` pour colonnes `Choice`/`ChoiceList`
- ✅ Export CSV/Excel fonctionnel

## 📦 Installation

```bash
pip install mcp-server-grist
```

## ⚙️ Configuration

### Variables d'environnement

```bash
export GRIST_API_KEY="votre-clé-api"
export GRIST_SERVER_URL="https://grist.example.com"  # Optionnel, défaut: https://docs.getgrist.com
```

### Configuration MCP (Claude Desktop)

```json
{
  "mcpServers": {
    "grist": {
      "command": "mcp-server-grist",
      "env": {
        "GRIST_API_KEY": "votre-clé-api",
        "GRIST_SERVER_URL": "https://grist.numerique.gouv.fr"
      }
    }
  }
}
```

## 📖 Utilisation

### Création de schéma complet

```python
schema = {
    "tables": {
        "Agents": {
            "columns": {
                "nom": {"type": "Text", "label": "Nom"},
                "prenom": {"type": "Text", "label": "Prénom"},
                "email": {"type": "Text", "label": "Email"},
                "service": {
                    "type": "Choice",
                    "label": "Service",
                    "choices": ["GIDI", "DTerMed", "Direction"]
                },
                "nom_complet": {
                    "type": "Text",
                    "formula": "$prenom + ' ' + $nom",
                    "label": "Nom complet"
                }
            }
        },
        "Projets": {
            "columns": {
                "nom": {"type": "Text", "label": "Nom du projet"},
                "budget": {"type": "Numeric", "label": "Budget (€)"},
                "chef_projet": {
                    "type": "Ref",
                    "target": "Agents",
                    "visible": "nom_complet",
                    "label": "Chef de projet"
                }
            }
        },
        "Taches": {
            "columns": {
                "titre": {"type": "Text"},
                "projet": {
                    "type": "Ref",
                    "target": "Projets",
                    "visible": "nom",
                    "reverse": "taches"  # Crée automatiquement Projets.taches
                },
                "responsable": {
                    "type": "Ref",
                    "target": "Agents",
                    "visible": "nom_complet"
                }
            }
        }
    },
    "data": {
        "Agents": [
            {"nom": "LAVAL", "prenom": "Nicolas", "service": "GIDI"}
        ]
    }
}

# Création via l'outil MCP
result = await create_schema(doc_id, schema)
```

### Création de colonne référence

```python
# Avec résolution automatique de visibleCol
result = await create_reference_column(
    doc_id="abc123",
    table_id="Taches",
    column_id="responsable",
    target_table="Agents",
    visible_column="nom_complet",  # Résolu automatiquement en colRef
    label="Responsable"
)

# Avec relation inverse
result = await create_reference_column(
    doc_id="abc123",
    table_id="Taches",
    column_id="projet",
    target_table="Projets",
    visible_column="nom",
    reverse_column="taches"  # Crée Projets.taches (RefList)
)
```

### Export de schéma

```python
# Export JSON
result = await export_schema(doc_id, format="json")

# Export Mermaid (diagramme ER)
result = await export_schema(doc_id, format="mermaid")
# Résultat:
# erDiagram
#     Agents {
#         string nom
#         string prenom
#     }
#     Projets {
#         string nom
#         int chef_projet
#     }
#     Projets }o--|| Agents : chef_projet
```

## 🔧 Outils disponibles

### Navigation

| Outil | Description |
|-------|-------------|
| `list_organizations` | Liste les organisations |
| `list_workspaces` | Liste les espaces de travail |
| `list_documents` | Liste les documents |
| `list_tables` | Liste les tables |
| `list_columns` | Liste les colonnes |

### Administration

| Outil | Description |
|-------|-------------|
| `create_table` | Crée une table avec colonnes |
| `modify_table` | Renomme une table |
| `delete_table` | Supprime une table |
| `create_column` | Crée une colonne |
| `modify_column` | Modifie une colonne |
| `delete_column` | Supprime une colonne |

### Schéma (v0.2.0)

| Outil | Description |
|-------|-------------|
| `create_schema` | Crée un schéma complet |
| `validate_schema` | Valide un schéma |
| `create_reference_column` | Crée une référence avec résolution auto |
| `export_schema` | Exporte un schéma existant |

### Données

| Outil | Description |
|-------|-------------|
| `list_records` | Liste les enregistrements |
| `add_grist_records` | Ajoute des enregistrements |
| `update_grist_records` | Met à jour des enregistrements |
| `delete_grist_records` | Supprime des enregistrements |
| `filter_sql_query` | Requête SQL simplifiée |
| `execute_sql_query` | Requête SQL personnalisée |

### Export

| Outil | Description |
|-------|-------------|
| `download_table_csv` | Export CSV d'une table |
| `download_document_excel` | Export Excel |
| `download_document_sqlite` | Export SQLite |

## 📋 Types de colonnes supportés

| Type | Description | Options |
|------|-------------|---------|
| `Text` | Texte libre | - |
| `Numeric` | Nombre décimal | `decimals` |
| `Int` | Nombre entier | - |
| `Bool` | Booléen | - |
| `Date` | Date | - |
| `DateTime` | Date et heure | - |
| `Choice` | Choix unique | `choices` (requis) |
| `ChoiceList` | Choix multiples | `choices` (requis) |
| `Ref:Table` | Référence | `visibleCol` |
| `RefList:Table` | Liste de références | `visibleCol` |
| `Attachments` | Pièces jointes | - |

## 🧪 Tests

```bash
# Installation des dépendances de dev
pip install -e ".[dev]"

# Lancer les tests
pytest tests/ -v

# Avec couverture
pytest tests/ --cov=mcp_server_grist
```

## 📝 Changelog

### v0.2.0 (2024-12-30)

#### Nouvelles fonctionnalités
- `create_schema` : Création de schémas complets
- `create_reference_column` : Références avec résolution automatique
- `validate_schema` : Validation avant création
- `export_schema` : Export JSON/YAML/Mermaid

#### Corrections
- Format payload `create_table` corrigé
- Format payload `modify_table` corrigé
- `widgetOptions` sérialisé en JSON string
- Gestion des `choices` pour Choice/ChoiceList
- Export CSV/Excel fonctionnel

### v0.1.x

- Version initiale avec outils de base

## 📄 Licence

MIT

## 🤝 Contribution

Les contributions sont les bienvenues ! Voir [CONTRIBUTING.md](CONTRIBUTING.md).

## 🙏 Remerciements

- [Grist](https://www.getgrist.com/) - La plateforme de données
- [Anthropic](https://www.anthropic.com/) - Le protocole MCP
- [CEREMA](https://www.cerema.fr/) - Support et tests
