"""
Outils d'administration Grist - Tables et Colonnes.

Corrections v0.2.0:
- create_table: format payload corrigé
- modify_table: format payload corrigé  
- create_column: gestion widgetOptions + choices
- modify_column: gestion widgetOptions comme string JSON
"""
import json
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import Context

from .utils import (
    prepare_table_payload,
    prepare_modify_table_payload,
    prepare_column_payload,
    prepare_modify_column_payload,
    build_success_response,
    build_error_response,
)


async def create_table(
    doc_id: str,
    table_id: str,
    columns: Optional[List[Dict[str, Any]]] = None,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Crée une nouvelle table dans un document Grist.
    
    Prérequis:
        - list_documents: Pour obtenir un doc_id valide
    
    Args:
        doc_id: L'ID du document
        table_id: ID de la nouvelle table (doit être unique dans le document)
        columns: Liste des définitions de colonnes (optionnel)
            Exemple: [
                {"id": "name", "type": "Text", "label": "Nom"},
                {"id": "status", "type": "Choice", "choices": ["A", "B", "C"]},
                {"id": "amount", "type": "Numeric", "widgetOptions": {"decimals": 2}}
            ]
    
    Returns:
        Dict avec statut, message et détails de la table créée
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        # Préparer le payload avec le bon format
        # CORRECTION v0.2.0: utiliser prepare_table_payload
        payload = prepare_table_payload(table_id, columns)
        
        # Créer la table
        response = await client.post(f"/docs/{doc_id}/tables", json=payload)
        
        # Vérifier le résultat
        tables_created = response.get("tables", [])
        if tables_created:
            created_table = tables_created[0]
            actual_id = created_table.get("id", table_id)
            
            result = build_success_response(
                f"Table '{table_id}' créée avec succès",
                table=created_table
            )
            
            # Warning si l'ID a été modifié par Grist
            if actual_id != table_id:
                result["warning"] = (
                    f"L'ID demandé '{table_id}' a été modifié en '{actual_id}' par Grist"
                )
            
            return result
        
        return build_success_response(
            f"Table '{table_id}' créée avec succès",
            table={"id": table_id}
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la création de la table: {str(e)}"
        )


async def modify_table(
    doc_id: str,
    table_id: str,
    new_table_id: Optional[str] = None,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Modifie les propriétés d'une table.
    
    Prérequis:
        - list_tables: Pour obtenir un table_id valide
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID actuel de la table
        new_table_id: Nouvel ID pour la table (optionnel)
    
    Returns:
        Dict avec statut et message de l'opération
    """
    try:
        if not new_table_id:
            return build_error_response(
                "Aucune modification demandée (new_table_id requis)"
            )
        
        client = ctx.request_context.lifespan_context.client
        
        # CORRECTION v0.2.0: format corrigé
        payload = prepare_modify_table_payload(table_id, new_table_id)
        
        await client.patch(f"/docs/{doc_id}/tables", json=payload)
        
        return build_success_response(
            f"Table '{table_id}' renommée en '{new_table_id}' avec succès"
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la modification de la table: {str(e)}"
        )


async def delete_table(
    doc_id: str,
    table_id: str,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Supprime une table d'un document.
    
    Attention:
        Cette action est irréversible et supprimera toutes les données
        de la table.
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table à supprimer
    
    Returns:
        Dict avec statut et message de l'opération
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        await client.delete(f"/docs/{doc_id}/tables/{table_id}")
        
        return build_success_response(
            f"Table '{table_id}' supprimée avec succès"
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la suppression de la table: {str(e)}"
        )


async def create_column(
    doc_id: str,
    table_id: str,
    column_id: str,
    column_type: str = "Text",
    label: Optional[str] = None,
    formula: Optional[str] = None,
    widget_options: Optional[Dict[str, Any]] = None,
    visible_col: Optional[int] = None,
    untie_col_id_from_label: bool = True,
    description: Optional[str] = None,
    choices: Optional[List[str]] = None,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Crée une nouvelle colonne dans une table Grist.
    
    Prérequis:
        - list_tables: Pour obtenir un table_id valide
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table
        column_id: ID de la nouvelle colonne
        column_type: Type de données. Types supportés:
            - Text, Numeric, Int, Bool, Date, DateTime
            - Choice, ChoiceList (avec paramètre choices)
            - Ref:TableId, RefList:TableId (références)
            - Attachments
        label: Libellé d'affichage (optionnel)
        formula: Formule Python pour colonnes calculées (optionnel)
        widget_options: Options d'affichage comme dict (optionnel)
        visible_col: colRef de la colonne à afficher pour les Ref (optionnel)
        untie_col_id_from_label: Dissocier l'ID du label (défaut: True)
        description: Description de la colonne (optionnel)
        choices: Liste de choix pour Choice/ChoiceList (optionnel)
    
    Returns:
        Dict avec statut, message et détails de la colonne créée
    
    Examples:
        # Colonne texte simple
        create_column(doc_id, "Table1", "name", "Text", label="Nom")
        
        # Colonne choix
        create_column(doc_id, "Table1", "status", "Choice", 
                      choices=["Actif", "Inactif", "En attente"])
        
        # Colonne référence
        create_column(doc_id, "Table1", "owner", "Ref:Users",
                      label="Propriétaire", visible_col=5)
        
        # Colonne calculée
        create_column(doc_id, "Table1", "full_name", "Text",
                      formula="$first_name + ' ' + $last_name")
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        # CORRECTION v0.2.0: utiliser prepare_column_payload
        payload = prepare_column_payload(
            column_id=column_id,
            column_type=column_type,
            label=label,
            formula=formula,
            widget_options=widget_options,
            visible_col=visible_col,
            untie_col_id_from_label=untie_col_id_from_label,
            description=description,
            choices=choices
        )
        
        response = await client.post(
            f"/docs/{doc_id}/tables/{table_id}/columns",
            json=payload
        )
        
        columns_created = response.get("columns", [])
        if columns_created:
            return build_success_response(
                f"Colonne '{column_id}' créée avec succès",
                column=columns_created[0]
            )
        
        return build_success_response(
            f"Colonne '{column_id}' créée avec succès",
            column={"id": column_id}
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la création de la colonne: {str(e)}"
        )


async def modify_column(
    doc_id: str,
    table_id: str,
    column_id: str,
    new_column_id: Optional[str] = None,
    column_type: Optional[str] = None,
    label: Optional[str] = None,
    formula: Optional[str] = None,
    widget_options: Optional[Dict[str, Any]] = None,
    visible_col: Optional[int] = None,
    untie_col_id_from_label: Optional[bool] = None,
    description: Optional[str] = None,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Modifie les propriétés d'une colonne.
    
    Prérequis:
        - list_columns: Pour obtenir un column_id valide
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table
        column_id: L'ID actuel de la colonne
        new_column_id: Nouvel ID pour la colonne (optionnel)
        column_type: Nouveau type de données (optionnel)
        label: Nouveau libellé d'affichage (optionnel)
        formula: Nouvelle formule (optionnel, "" pour supprimer)
        widget_options: Nouvelles options d'affichage (optionnel)
        visible_col: Nouveau colRef pour les Ref (optionnel)
        untie_col_id_from_label: Dissocier l'ID du label (optionnel)
        description: Nouvelle description (optionnel)
    
    Returns:
        Dict avec statut et message de l'opération
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        # CORRECTION v0.2.0: utiliser prepare_modify_column_payload
        payload = prepare_modify_column_payload(
            column_id=column_id,
            new_column_id=new_column_id,
            column_type=column_type,
            label=label,
            formula=formula,
            widget_options=widget_options,
            visible_col=visible_col,
            untie_col_id_from_label=untie_col_id_from_label,
            description=description
        )
        
        # Vérifier qu'il y a des modifications
        if not payload["columns"][0]["fields"]:
            return build_error_response(
                "Aucune modification demandée"
            )
        
        await client.patch(
            f"/docs/{doc_id}/tables/{table_id}/columns",
            json=payload
        )
        
        return build_success_response(
            f"Colonne '{column_id}' modifiée avec succès"
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la modification de la colonne: {str(e)}"
        )


async def delete_column(
    doc_id: str,
    table_id: str,
    column_id: str,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Supprime une colonne d'une table.
    
    Attention:
        Cette action est irréversible et supprimera toutes les données
        de la colonne.
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table
        column_id: L'ID de la colonne à supprimer
    
    Returns:
        Dict avec statut et message de l'opération
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        await client.delete(
            f"/docs/{doc_id}/tables/{table_id}/columns/{column_id}"
        )
        
        return build_success_response(
            f"Colonne '{column_id}' supprimée avec succès"
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la suppression de la colonne: {str(e)}"
        )


async def list_tables(
    doc_id: str,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Liste toutes les tables dans un document Grist.
    
    Args:
        doc_id: L'ID du document
    
    Returns:
        Dict avec statut, message et liste des tables
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        response = await client.get(f"/docs/{doc_id}/tables")
        tables = response.get("tables", [])
        
        return build_success_response(
            f"Found {len(tables)} tables in document {doc_id}",
            tables=tables
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la récupération des tables: {str(e)}"
        )


async def list_columns(
    doc_id: str,
    table_id: str,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Liste toutes les colonnes dans une table Grist.
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table
    
    Returns:
        Dict avec statut, message et liste des colonnes
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        response = await client.get(
            f"/docs/{doc_id}/tables/{table_id}/columns"
        )
        columns = response.get("columns", [])
        
        return build_success_response(
            f"Found {len(columns)} columns in table {table_id}",
            columns=columns
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors de la récupération des colonnes: {str(e)}"
        )


def register_administration_tools(mcp):
    """Enregistre les outils d'administration."""
    mcp.tool()(create_table)
    mcp.tool()(modify_table)
    mcp.tool()(delete_table)
    mcp.tool()(create_column)
    mcp.tool()(modify_column)
    mcp.tool()(delete_column)
    mcp.tool()(list_tables)
    mcp.tool()(list_columns)
