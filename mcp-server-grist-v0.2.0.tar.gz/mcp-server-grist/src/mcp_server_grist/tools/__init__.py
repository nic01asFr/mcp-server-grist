"""
Grist MCP Server Tools.

Ce module expose les fonctions d'enregistrement des outils.
"""
from .administration import register_administration_tools
from .schema import register_schema_tools
from .downloads import register_download_tools


def register_all_tools(mcp):
    """Enregistre tous les outils disponibles."""
    register_administration_tools(mcp)
    register_schema_tools(mcp)
    register_download_tools(mcp)


__all__ = [
    "register_all_tools",
    "register_administration_tools",
    "register_schema_tools",
    "register_download_tools",
]
