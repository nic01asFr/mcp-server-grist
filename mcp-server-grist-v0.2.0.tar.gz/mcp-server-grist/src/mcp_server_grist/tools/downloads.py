"""
Outils de téléchargement Grist.

Corrections v0.2.0:
- download_table_csv: Implémentation complète
- download_document_excel: Gestion du paramètre tableId
"""
import base64
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import Context

from .utils import build_success_response, build_error_response


async def download_table_csv(
    doc_id: str,
    table_id: str,
    header: str = "label",
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Télécharge une table Grist au format CSV.
    
    Prérequis:
        - list_documents: Pour obtenir un doc_id valide
        - list_tables: Pour obtenir un table_id valide
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table
        header: Format des en-têtes ("label", "id", ou "none")
    
    Returns:
        Dict avec statut, message et contenu CSV
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        # Construire l'URL avec les paramètres
        url = f"/docs/{doc_id}/download/csv"
        params = {
            "tableId": table_id,
            "header": header
        }
        
        # Télécharger le CSV
        response = await client.get_raw(url, params=params)
        
        # Décoder le contenu
        if hasattr(response, 'content'):
            content = response.content.decode('utf-8')
        elif hasattr(response, 'text'):
            content = response.text
        else:
            content = str(response)
        
        return build_success_response(
            f"Table '{table_id}' téléchargée au format CSV",
            content=content,
            filename=f"{table_id}.csv",
            content_type="text/csv"
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors du téléchargement CSV: {str(e)}"
        )


async def download_document_excel(
    doc_id: str,
    table_id: Optional[str] = None,
    header: str = "label",
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Télécharge un document Grist au format Excel.
    
    Note: L'API Grist requiert souvent un tableId. Si non fourni,
    la fonction tente de télécharger toutes les tables.
    
    Prérequis:
        - list_documents: Pour obtenir un doc_id valide
    
    Args:
        doc_id: L'ID du document
        table_id: L'ID de la table (optionnel mais recommandé)
        header: Format des en-têtes ("label", "id", ou "none")
    
    Returns:
        Dict avec statut, message et contenu encodé en base64
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        url = f"/docs/{doc_id}/download/xlsx"
        params = {"header": header}
        
        # Si pas de table_id, récupérer la première table
        if not table_id:
            try:
                tables_response = await client.get(f"/docs/{doc_id}/tables")
                tables = tables_response.get("tables", [])
                if tables:
                    # Prendre la première table non-système
                    for t in tables:
                        tid = t.get("id", "")
                        if not tid.startswith("_"):
                            table_id = tid
                            break
            except Exception:
                pass
        
        if table_id:
            params["tableId"] = table_id
        
        # Télécharger le fichier Excel
        response = await client.get_raw(url, params=params)
        
        # Encoder en base64
        if hasattr(response, 'content'):
            content_bytes = response.content
        else:
            content_bytes = bytes(response)
        
        content_base64 = base64.b64encode(content_bytes).decode('utf-8')
        
        filename = f"{doc_id}"
        if table_id:
            filename += f"_{table_id}"
        filename += ".xlsx"
        
        return build_success_response(
            f"Document téléchargé au format Excel",
            content_base64=content_base64,
            filename=filename,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            table_id=table_id
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors du téléchargement Excel: {str(e)}"
        )


async def download_document_sqlite(
    doc_id: str,
    nohistory: bool = False,
    template: bool = False,
    ctx: Context = None
) -> Dict[str, Any]:
    """
    Télécharge un document Grist au format SQLite.
    
    Prérequis:
        - list_documents: Pour obtenir un doc_id valide
    
    Args:
        doc_id: L'ID du document
        nohistory: Si True, exclut l'historique des modifications
        template: Si True, télécharge comme modèle (sans données utilisateur)
    
    Returns:
        Dict avec statut, message et contenu encodé en base64
    """
    try:
        client = ctx.request_context.lifespan_context.client
        
        url = f"/docs/{doc_id}/download"
        params = {}
        
        if nohistory:
            params["nohistory"] = "1"
        if template:
            params["template"] = "1"
        
        response = await client.get_raw(url, params=params)
        
        if hasattr(response, 'content'):
            content_bytes = response.content
        else:
            content_bytes = bytes(response)
        
        content_base64 = base64.b64encode(content_bytes).decode('utf-8')
        
        return build_success_response(
            f"Document '{doc_id}' téléchargé au format SQLite",
            content_base64=content_base64,
            filename=f"{doc_id}.grist",
            content_type="application/x-sqlite3"
        )
        
    except Exception as e:
        return build_error_response(
            f"Erreur lors du téléchargement SQLite: {str(e)}"
        )


def register_download_tools(mcp):
    """Enregistre les outils de téléchargement."""
    mcp.tool()(download_table_csv)
    mcp.tool()(download_document_excel)
    mcp.tool()(download_document_sqlite)
