"""
MCP Server Grist - Serveur MCP pour Grist.

Version 0.2.0
"""
__version__ = "0.2.0"
__author__ = "Nicolas LAVAL"
__email__ = "nicolas.laval@cerema.fr"

from .types import (
    ColumnType,
    ColumnDefinition,
    TableDefinition,
    SchemaDefinition,
    GRIST_COLUMN_TYPES,
    validate_column_type,
    prepare_widget_options,
    parse_schema_dict,
)

__all__ = [
    "__version__",
    "ColumnType",
    "ColumnDefinition",
    "TableDefinition",
    "SchemaDefinition",
    "GRIST_COLUMN_TYPES",
    "validate_column_type",
    "prepare_widget_options",
    "parse_schema_dict",
]
